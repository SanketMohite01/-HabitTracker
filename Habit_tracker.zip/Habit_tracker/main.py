import requests
from datetime import datetime


username = "sanketm2"  
token = "sanket@2025Secure123"  
graph_id="graph1"

pixela_endpoint = "https://pixe.la/v1/users"
user_params = {
    "token": token,
    "username": username,
    "agreeTermsOfService": "yes",
    "notMinor": "yes",
}


#user_response = requests.post(url=pixela_endpoint, json=user_params)
#print("User creation response:", user_response.text)


graph_endpoint = f"{pixela_endpoint}/{username}/graphs"
graph_config = {
    "id": "graph1",
    "name": "Coding Graph",
    "unit": "Hours",
    "type": "int",
    "color": "sora"
}
headers = {
    "X-USER-TOKEN": token
}

#graph_response = requests.post(url=graph_endpoint, json=graph_config, headers=headers)
#print("Graph creation response:", graph_response.text)
today = datetime(year=2025,month=6,day=11)
#print(today.strftime("%Y%m%d"))
get_graph_endpoint = f"{pixela_endpoint}/{username}/graphs/{graph_id}"


param = {
    "date": today.strftime("%Y%m%d"),      
    "quantity": "5"
}

#response = requests.post(url=get_graph_endpoint, json=param, headers=headers)
#print(response.text)

update_graph_endpoint=f"{pixela_endpoint}/{username}/graphs/{graph_id}/{today.strftime('%Y%m%d')}"


new_pix_data={
    "quantity":"2"

}
#response=requests.put(url=update_graph_endpoint,json=new_pix_data,headers=headers)
#print(response.text)


delete_graph_endpoint=f"{pixela_endpoint}/{username}/graphs/{graph_id}/{today.strftime('%Y%m%d')}"

response=requests.delete(url=delete_graph_endpoint,headers=headers)
print(response.text)
